# Controle de Entrada e Pátio — pacote completo

## /app
Site principal (HTML/JS), o que fica hospedado no Vercel.
Sobe pro seu repositório git de sempre e dá push normalmente.

## /cloud-function
Código da Cloud Function que sincroniza o Firestore com o Google Sheets
EM TEMPO REAL (dispara a cada registro criado/editado). Publica direto
pelo Google Cloud Console (console.cloud.google.com/functions) — NÃO
faz parte do repositório do app, é publicada separadamente no Firebase/GCP.

## /apps-script-legado
Versão antiga (script que rodava a cada 15 min dentro do Google Sheets).
Só mantenha se quiser um backup/redundância — não é mais necessário se
a Cloud Function estiver funcionando.

---
Gerado em: $(date +%d/%m/%Y)
